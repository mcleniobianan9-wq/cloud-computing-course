# Cloud Computing Course Repository

> *A collection of activities, outputs, and learning resources for Cloud Computing.*

## 📌 About This Repository

This repository serves as my organized workspace for all course requirements, including:

- Class notes and summaries
- Lab activities and exercises
- Mini-projects
- Reflection papers

## 👤 Student Information

- **Name:** John Michael Bernales
- **Course/Section:** (BSIT-4G)
- **Instructor:** (Mrs. JENKIELYN TORRES)
- **School Year:** 2026–2027

## 📂 Repository Structure

```
cloud-computing-course/
├── activities/
├── projects/
├── notes/
├── reflections/
└── README.md
```

## 📖 Key Concepts Covered

- Cloud Computing Basics
- Service Models (IaaS, PaaS, SaaS)
- Deployment Models (Public, Private, Hybrid, Community)
- Version Control with Git & GitHub
- Cloud Infrastructure Management
